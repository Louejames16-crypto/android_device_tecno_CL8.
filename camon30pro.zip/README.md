# Android device tree for TECNO TECNO CL8 (cl8)

# Smartphone Specifications

| Category | Specification |
|----------|---------------|
| **Network** | GSM / HSPA / LTE / 5G |
| **Launch** | Announced: 2024, February 27<br>Released: 2024, April 02 |
| **Status** | Available |
| **Body** | Dimensions: 164 x 74.5 x 7.7 mm (6.46 x 2.93 x 0.30 in)<br>Weight: 188.6 g (6.67 oz)<br>Build: Glass front, glass back or silicone polymer back (eco leather)<br>SIM: Nano-SIM + Nano-SIM |
| **Display** | Type: AMOLED, 144Hz<br>Size: 6.78 inches, 109.9 cm² (~89.9% screen-to-body ratio)<br>Resolution: 1080 x 2436 pixels (~393 ppi density) |
| **Platform** | OS: Android 14, up to 2 major Android upgrades, HIOS 14<br>Chipset: Mediatek Dimensity 8200 Ultimate (4 nm)<br>CPU: Octa-core (1x3.1 GHz Cortex-A78 & 3x3.0 GHz Cortex-A78 & 4x2.0 GHz Cortex-A55)<br>GPU: Mali-G610 MC6 |
| **Memory** | Card slot: No<br>Internal: 256GB 12GB RAM, 512GB 12GB RAM |
| **Main Camera** | Triple: 50 MP, f/1.9, 23mm (wide), 1/1.56", 1.0µm, PDAF, OIS<br>50 MP, f/2.2, 14mm, 114˚ (ultrawide), 1/2.76", 0.64µm, PDAF (Auxiliary lens)<br>Features: Dual-LED flash, HDR, panorama<br>Video: 4K@30/60fps (HDR), 1080p@30fps |
| **Selfie Camera** | Single: 50 MP, f/2.5, 24mm (wide), 1/2.8", 0.64µm, PDAF<br>Video: Yes |
| **Sound** | Loudspeaker: Yes, with dual speakers<br>3.5mm jack: No<br>Audio: 24-bit/192kHz Hi-Res audio |
| **Comms** | WLAN: Wi-Fi 802.11 a/b/g/n/ac, dual-band<br>Bluetooth: 5.3, A2DP, LE<br>Positioning: GPS<br>NFC: Yes<br>Infrared port: Yes<br>Radio: FM radio<br>USB: USB Type-C 2.0, OTG |
| **Features** | Sensors: Fingerprint (under display, optical), accelerometer, gyro, compass |
| **Battery** | Type: 5000 mAh<br>Charging: 70W wired, 0-100% in 47 min |
| **Misc** | Colors: Iceland Basaltic Dark, Alps Snowy Silver<br>Models: CL8 |
| **Our Tests** | Performance: AnTuTu: 949357 (v10), GeekBench: 3931 (v6), 3DMark: 1727 (Wild Life Extreme)<br>Display: 998 nits max brightness (measured)<br>Loudspeaker: -25.5 LUFS (Very good)<br>Battery: Active use score 14:29h |

## Device Photo
![CL8](https://fdn2.gsmarena.com/vv/pics/tecno/tecno-camon-30-pro-2.jpg)

```
#
# Copyright (C) 2026 The Android Open Source Project
# Copyright (C) 2026 SebaUbuntu's TWRP device tree generator
#
# SPDX-License-Identifier: Apache-2.0
#
```
